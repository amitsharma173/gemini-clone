import React, { useContext } from 'react';
import './Main.css';
import { assets } from '../../assets/assets';
import { Context } from '../../contex/Context';

const Main = () => {
  const { onSent, recentPromt, showResult, loading, resultData, setInput, input } = useContext(Context);

  // Function to handle 'Enter' key press
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && input) {
      onSent();
    }
  };

  // Function to format and separate code from explanation
  const formatResponse = () => {
    if (typeof resultData === 'string') {
      const explanationIndex = resultData.indexOf('Explanation:');
      const codeBlock = explanationIndex !== -1
        ? resultData.substring(0, explanationIndex).trim()
        : resultData.trim();
      const explanation = explanationIndex !== -1
        ? resultData.substring(explanationIndex).replace(/<\/?b>|<\/?br\s*\/?>/g, '').trim()
        : '';

      return (
        <div>
          {/* Code Block */}
          <div className="formatted-code">
            <pre>
              <code>{codeBlock}</code>
            </pre>
          </div>
          {/* Explanation Section */}
          {explanation && (
            <div className="formatted-explanation">
              {explanation.split('\n').map((line, index) => (
                <p key={index}>{line}</p>
              ))}
            </div>
          )}
        </div>
      );
    }
    return <p>{resultData}</p>;
  };

  // Function to copy the code block to clipboard
  const copyToClipboard = () => {
    const explanationIndex = resultData.indexOf('Explanation:');
    const codeBlock = explanationIndex !== -1
      ? resultData.substring(0, explanationIndex).trim()
      : resultData.trim();
    
    navigator.clipboard.writeText(codeBlock)
      .then(() => {
        alert('Code copied to clipboard!');
      })
      .catch(err => {
        console.error('Error copying to clipboard', err);
      });
  };

  return (
    <div className="main">
      <div className="nav">
        <div className="devloped">
          <p>
            <span>AI-Chat Bot - developed by AMIT KUMAR</span>
          </p>
        </div>
        <img src={assets.user_icon} alt="" />
      </div>
      <div className="main-container">
        {!showResult ? (
          <>
            <div className="greet">
              <p>
                <span>Hello, Dev.</span>
              </p>
              <p>How Can I Help you today?</p>
            </div>
            <div className="cards">
              <div className="card">
                <p>Suggest beautiful places to see on an upcoming road trip</p>
                <img src={assets.compass_icon} alt="" />
              </div>
              <div className="card">
                <p>Suggest beautiful places to see on an upcoming road trip</p>
                <img src={assets.bulb_icon} alt="" />
              </div>
              <div className="card">
                <p>Suggest beautiful places to see on an upcoming road trip</p>
                <img src={assets.message_icon} alt="" />
              </div>
              <div className="card">
                <p>Suggest beautiful places to see on an upcoming road trip</p>
                <img src={assets.code_icon} alt="" />
              </div>
            </div>
          </>
        ) : (
          <div className="result">
            <div className="result-title">
              <img src={assets.user_icon} alt="" />
              <p>{recentPromt}</p>
            </div>
            <div className="result-data">
              <img src={assets.gemini_icon} alt="" />
              {loading ? (
                <div className="loader">
                  <hr />
                  <hr />
                  <hr />
                </div>
              ) : (
                formatResponse()
              )}
            </div>
            {/* Copy Button */}
            <button onClick={copyToClipboard}>
              Copy Code
            </button>
          </div>
        )}
        <br /><br /><br />

        <div className="main-bottom">
          <div className="search-box">
            <input
              onChange={(e) => setInput(e.target.value)}
              value={input}
              type="text"
              placeholder="Enter a Prompt here"
              onKeyDown={handleKeyDown} // Add keydown listener
            />
            <div>
              {input ? <img onClick={() => onSent()} src={assets.send_icon} alt="" /> : null}
            </div>
          </div>
          <p className="bottom-info">
            AI-CHAT BOT may display inaccurate info, including about people, so double-check its responses.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Main;
